package hangmanClient.view;

public interface ServerResponseObserver {
	
	public void newServerResponse(String response);

}
